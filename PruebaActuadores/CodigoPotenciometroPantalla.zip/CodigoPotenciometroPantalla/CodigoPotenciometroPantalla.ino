#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

int valor = 0;
int incremento = 1;

void setup() {
  Wire.begin(22, 21);  // SDA = 22, SCL = 21

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Potenciometro");
}

void loop() {

  // Mostrar valor
  lcd.setCursor(0, 1);
  lcd.print("Valor: ");
  lcd.print(valor);
  lcd.print("   ");  // Borra restos de numeros anteriores

  // Subir hasta 100
  if (valor >= 100) {
    incremento = -1;
  }

  // Bajar hasta 0
  if (valor <= 0) {
    incremento = 1;
  }

  valor += incremento;

  delay(50);
}